#!/usr/bin/env python3
"""
Individual Figure Generator
Run specific figures independently

Usage:
python individual_figures.py --figure 1    # Generate only Figure 1
python individual_figures.py --figure all  # Generate all figures
python individual_figures.py --list        # List all available figures
"""

import argparse
import sys
import os

# Import the main figures module
from manuscript_figures import *

def list_figures():
    """List all available figures"""
    figures = {
        1: "LSTM Network Architecture",
        2: "Data Flow and Preprocessing Pipeline", 
        3: "Comprehensive Model Performance Comparison",
        4: "S&P 500 Time Series and Model Predictions",
        5: "Regime-Specific Performance Analysis",
        6: "Statistical Significance Testing Results",
        7: "LSTM Attention Analysis",
        8: "Rolling Window Performance Analysis",
        9: "Computational Efficiency Analysis",
        10: "Multi-horizon Forecast Performance"
    }
    
    print("Available Figures:")
    print("=" * 50)
    for num, title in figures.items():
        print(f"Figure {num}: {title}")
    print("=" * 50)

def generate_figure(figure_num):
    """Generate a specific figure"""
    figure_functions = {
        1: create_lstm_architecture_diagram,
        2: create_data_flow_diagram,
        3: create_performance_comparison,
        4: create_time_series_plot,
        5: create_regime_analysis,
        6: create_statistical_significance,
        7: create_attention_analysis,
        8: create_rolling_window_analysis,
        9: create_computational_analysis,
        10: create_forecast_horizon_analysis
    }
    
    if figure_num not in figure_functions:
        print(f"Error: Figure {figure_num} not found!")
        print("Use --list to see available figures")
        return False
    
    try:
        print(f"Generating Figure {figure_num}...")
        figure_functions[figure_num]()
        print(f"Figure {figure_num} generated successfully!")
        return True
    except Exception as e:
        print(f"Error generating Figure {figure_num}: {e}")
        return False

def main():
    parser = argparse.ArgumentParser(description='Generate individual manuscript figures')
    parser.add_argument('--figure', type=str, help='Figure number (1-10) or "all"')
    parser.add_argument('--list', action='store_true', help='List all available figures')
    
    args = parser.parse_args()
    
    if args.list:
        list_figures()
        return
    
    if not args.figure:
        print("Error: Please specify a figure number or use --list")
        print("Usage: python individual_figures.py --figure 1")
        return
    
    if args.figure.lower() == 'all':
        print("Generating all figures...")
        success_count = 0
        for i in range(1, 11):
            if generate_figure(i):
                success_count += 1
        print(f"\nCompleted: {success_count}/10 figures generated successfully")
    else:
        try:
            figure_num = int(args.figure)
            if 1 <= figure_num <= 10:
                generate_figure(figure_num)
            else:
                print("Error: Figure number must be between 1 and 10")
        except ValueError:
            print("Error: Invalid figure number. Please use a number between 1-10 or 'all'")

if __name__ == "__main__":
    main()

