import matplotlib.pyplot as plt
import numpy as np
from datetime import datetime, timedelta

# Generate data
np.random.seed(42)
dates = [datetime(2019, 1, 1) + timedelta(days=i) for i in range(730)]
n = len(dates)

# S&P 500 prices with COVID crash
prices = 2800 + np.linspace(0, 600, n) + np.random.normal(0, 50, n)
for i in range(425, 485):  # COVID period
    prices[i] += -800 * np.exp(-((i - 425) / 15)**2)

# Model predictions
transformer = prices + np.random.normal(0, 25, n)
lstm = prices + np.random.normal(0, 35, n)
arima = prices + np.random.normal(0, 80, n)
var = prices + np.random.normal(0, 60, n)

# Errors
t_err = np.abs(prices - transformer)
l_err = np.abs(prices - lstm)
a_err = np.abs(prices - arima)
v_err = np.abs(prices - var)

# Plot
fig, (ax1, ax2) = plt.subplots(2, 1, figsize=(16, 12))

# Prices
ax1.plot(dates, prices, 'k-', linewidth=2, label='Actual S&P 500')
ax1.plot(dates, lstm, 'g-', linewidth=1.5, label='LSTM Prediction')
ax1.plot(dates, transformer, color='orange', linewidth=1.5, label='Transformer Prediction')
ax1.plot(dates, arima, 'r-', linewidth=1.5, label='ARIMA Prediction')
ax1.plot(dates, var, 'b-', linewidth=1.5, label='VAR Prediction')
ax1.axvspan(datetime(2020, 3, 1), datetime(2020, 5, 1), alpha=0.3, color='red', label='COVID-19 Period')
ax1.set_title('Figure 4a: S&P 500 Actual vs Predicted Prices (2019-2020)', fontweight='bold')
ax1.set_ylabel('Price ($)')
ax1.legend()
ax1.grid(True, alpha=0.3)

# Errors
ax2.plot(dates, l_err, 'g-', label='LSTM Error')
ax2.plot(dates, t_err, color='orange', label='Transformer Error')
ax2.plot(dates, a_err, 'r-', label='ARIMA Error')
ax2.plot(dates, v_err, 'b-', label='VAR Error')
ax2.axvspan(datetime(2020, 3, 1), datetime(2020, 5, 1), alpha=0.3, color='red')
ax2.set_title('Figure 4b: Absolute Prediction Errors', fontweight='bold')
ax2.set_ylabel('Absolute Error ($)')
ax2.set_xlabel('Date')
ax2.legend()
ax2.grid(True, alpha=0.3)

plt.tight_layout()
plt.savefig('Figure_4_Time_Series_with_Transformer.png', dpi=300, bbox_inches='tight')
print("Figure created successfully!")
print(f"Transformer RMSE: {np.sqrt(np.mean(t_err**2)):.2f}")
print(f"LSTM RMSE: {np.sqrt(np.mean(l_err**2)):.2f}")
print(f"ARIMA RMSE: {np.sqrt(np.mean(a_err**2)):.2f}")
print(f"VAR RMSE: {np.sqrt(np.mean(v_err**2)):.2f}")
plt.close()

