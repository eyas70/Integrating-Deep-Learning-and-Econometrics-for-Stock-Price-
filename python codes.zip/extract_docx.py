#!/usr/bin/env python3
import os
from docx import Document

def extract_text_from_docx(docx_path):
    """استخراج النص من ملف docx"""
    try:
        doc = Document(docx_path)
        text = []
        
        for paragraph in doc.paragraphs:
            text.append(paragraph.text)
        
        # استخراج النص من الجداول أيضاً
        for table in doc.tables:
            for row in table.rows:
                for cell in row.cells:
                    text.append(cell.text)
        
        return '\n'.join(text)
    except Exception as e:
        return f"خطأ في قراءة الملف: {str(e)}"

# قائمة ملفات docx
docx_files = [
    'coverletter.docx',
    'Highlights.docx', 
    'IntegratingDeepLearningandEconometricsforStockPricePrediction.docx',
    'Manuscript.docx',
    'ManuscriptNumber.docx'
]

# استخراج النص من كل ملف وحفظه
for docx_file in docx_files:
    if os.path.exists(docx_file):
        print(f"معالجة ملف: {docx_file}")
        text = extract_text_from_docx(docx_file)
        
        # حفظ النص في ملف txt
        txt_file = docx_file.replace('.docx', '.txt')
        with open(txt_file, 'w', encoding='utf-8') as f:
            f.write(text)
        
        print(f"تم حفظ النص في: {txt_file}")
    else:
        print(f"الملف غير موجود: {docx_file}")

print("انتهت عملية الاستخراج")

